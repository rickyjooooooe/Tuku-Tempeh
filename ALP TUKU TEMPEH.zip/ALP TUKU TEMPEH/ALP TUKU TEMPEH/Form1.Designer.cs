﻿namespace ALP_TUKU_TEMPEH
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnl_gambartukutempeh = new System.Windows.Forms.Panel();
            this.lbl_welcomeTo = new System.Windows.Forms.Label();
            this.lbl_TukuTempeh = new System.Windows.Forms.Label();
            this.picture_next = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picture_next)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_gambartukutempeh
            // 
            this.pnl_gambartukutempeh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl_gambartukutempeh.BackgroundImage")));
            this.pnl_gambartukutempeh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnl_gambartukutempeh.Location = new System.Drawing.Point(-2, 1);
            this.pnl_gambartukutempeh.Name = "pnl_gambartukutempeh";
            this.pnl_gambartukutempeh.Size = new System.Drawing.Size(544, 555);
            this.pnl_gambartukutempeh.TabIndex = 0;
            // 
            // lbl_welcomeTo
            // 
            this.lbl_welcomeTo.AutoSize = true;
            this.lbl_welcomeTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcomeTo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lbl_welcomeTo.Location = new System.Drawing.Point(641, 194);
            this.lbl_welcomeTo.Name = "lbl_welcomeTo";
            this.lbl_welcomeTo.Size = new System.Drawing.Size(252, 38);
            this.lbl_welcomeTo.TabIndex = 1;
            this.lbl_welcomeTo.Text = "WELCOME TO";
            this.lbl_welcomeTo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_TukuTempeh
            // 
            this.lbl_TukuTempeh.AutoSize = true;
            this.lbl_TukuTempeh.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TukuTempeh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lbl_TukuTempeh.Location = new System.Drawing.Point(709, 233);
            this.lbl_TukuTempeh.Name = "lbl_TukuTempeh";
            this.lbl_TukuTempeh.Size = new System.Drawing.Size(111, 38);
            this.lbl_TukuTempeh.TabIndex = 2;
            this.lbl_TukuTempeh.Text = "TUKU";
            // 
            // picture_next
            // 
            this.picture_next.Image = ((System.Drawing.Image)(resources.GetObject("picture_next.Image")));
            this.picture_next.Location = new System.Drawing.Point(857, 417);
            this.picture_next.Name = "picture_next";
            this.picture_next.Size = new System.Drawing.Size(84, 83);
            this.picture_next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_next.TabIndex = 3;
            this.picture_next.TabStop = false;
            this.picture_next.Click += new System.EventHandler(this.picture_next_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(682, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 38);
            this.label1.TabIndex = 4;
            this.label1.Text = "TEMPEH";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(953, 502);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picture_next);
            this.Controls.Add(this.lbl_TukuTempeh);
            this.Controls.Add(this.lbl_welcomeTo);
            this.Controls.Add(this.pnl_gambartukutempeh);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pembuka";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picture_next)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_gambartukutempeh;
        private System.Windows.Forms.Label lbl_welcomeTo;
        private System.Windows.Forms.Label lbl_TukuTempeh;
        private System.Windows.Forms.PictureBox picture_next;
        private System.Windows.Forms.Label label1;
    }
}

